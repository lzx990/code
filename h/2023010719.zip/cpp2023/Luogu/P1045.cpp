#include<bits/stdc++.h>
using namespace std;
int p;

int main()
{
    scanf("%d",&p);
    printf("%d\n",int(1.0*p*log10(2)+0.9999));
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/