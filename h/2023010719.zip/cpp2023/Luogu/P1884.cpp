#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,a[1010][5],li[4010],m,f[4010][4010];
LL ans;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=4;j++)
        {
            scanf("%d",&a[i][j]);
            li[++m]=a[i][j];
        }
    }
    sort(li+1,li+1+m);
    m=unique(li+1,li+1+m)-li-1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=4;j++)
        {
            a[i][j]=lower_bound(li+1,li+1+m,a[i][j])-li;
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=a[i][1];j<a[i][3];j++)
        {
            f[j][a[i][2]]++;
            f[j][a[i][4]]--;
        }
    }
    for(int i=1;i<m;i++)
    {
        for(int j=1;j<m;j++)
        {
            f[i][j]+=f[i][j-1];
        }
    }
    for(int i=1;i<m;i++)
    {
        for(int j=1;j<m;j++)
        {
            if(f[i][j])
            {
                ans+=1LL*(li[i+1]-li[i])*(li[j+1]-li[j]);
            }
        }
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/