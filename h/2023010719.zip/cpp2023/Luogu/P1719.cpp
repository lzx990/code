#include<bits/stdc++.h>
using namespace std;
int n,a[130][130],s[130][130],ans=INT_MIN;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            scanf("%d",&a[i][j]);
            s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            for(int k=i;k<=n;k++)
            {
                for(int l=j;l<=n;l++)
                {
                    ans=max(ans,s[i-1][j-1]+s[k][l]-s[i-1][l]-s[k][j-1]);
                }
            }
        }
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/