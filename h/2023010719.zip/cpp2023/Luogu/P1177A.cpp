#include<bits/stdc++.h>
using namespace std;
int b[114514],a[114514],n;
void ms(int a[],int l,int r)
{
    if(l==r) return;
    int mid=(l+r)>>1;
    ms(a,l,mid);
    ms(a,mid+1,r);
    for(int i=l,j=mid+1,k=l;k<=r;k++)
    {
        if(i==mid+1)
        {
            b[k]=a[j++];
        }
        else if(j==r+1)
        {
            b[k]=a[i++];
        }
        else
        {
            b[k]=(a[i]<a[j])?(a[i++]):(a[j++]);
        }
    }
    for(int i=l;i<=r;i++)
    {
        a[i]=b[i];
    }
    return;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    ms(a,1,n);
    for(int i=1;i<=n;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/