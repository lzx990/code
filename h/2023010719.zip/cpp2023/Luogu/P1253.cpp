#include<bits/stdc++.h>

#define lc (rt<<1)
#define rc ((rt<<1)|1)
#define md ((l+r)>>1)
#define LL long long

using namespace std;

int n,m;
LL a[1000010];
const LL INF=1145141919810;
struct node
{
    LL v,tp,tc;
}seg[4000010];

bool inseg(int l,int r,int L,int R)
{
    return ((L<=l) && (r<=R));
}
bool outseg(int l,int r,int L,int R)
{
    return ((l>R) || (r<L));
}
void gettag(int op,int rt,LL x)
{
    if(op==1)
    {
        seg[rt].tp=0;
        seg[rt].tc=x;
        seg[rt].v=x;
    }
    else
    {
        if(seg[rt].tc!=INF) seg[rt].tc+=x;
        else seg[rt].tp+=x;
        seg[rt].v+=x;
    }
}

void pushup(int rt)
{
    seg[rt].v=max(seg[lc].v,seg[rc].v);
    return;
}
void pushdown(int rt)
{
    if(seg[rt].tc!=INF)
    {
        gettag(1,lc,seg[rt].tc);
        gettag(1,rc,seg[rt].tc);
        seg[rt].tc=INF;
    }
    else
    {
        gettag(2,lc,seg[rt].tp);
        gettag(2,rc,seg[rt].tp);
        seg[rt].tp=0;
    }
}
void build(int rt,int l,int r)
{
    seg[rt].tc=INF;
    seg[rt].tp=0;
    if(l==r)
    {
        seg[rt].v=a[l];
        return;
    }
    build(lc,l,md);
    build(rc,md+1,r);
    pushup(rt);
    return;
}
void change(int op,int rt,int l,int r,int L,int R,LL k)
{
    if(inseg(l,r,L,R))
    {
        gettag(op,rt,k);
        return;
    }
    else if(!outseg(l,r,L,R))
    {
        pushdown(rt);
        change(op,lc,l,md,L,R,k);
        change(op,rc,md+1,r,L,R,k);
        pushup(rt);
        return;
    }
    return;
}
LL query(int rt,int l,int r,int L,int R)
{
    if(inseg(l,r,L,R))
    {
        return seg[rt].v;
    }
    else if(outseg(l,r,L,R))
    {
        return -1145141919810;
    }
    else
    {
        pushdown(rt);
        return max(query(lc,l,md,L,R),query(rc,md+1,r,L,R));
    }
}

int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
    }
    build(1,1,n);
    while(m--)
    {
        int op;
        scanf("%d",&op);
        if(op==1)
        {
            int l,r;
            LL x;
            scanf("%d%d%lld",&l,&r,&x);
            change(op,1,1,n,l,r,x);
        }
        if(op==2)
        {
            int l,r;
            LL x;
            scanf("%d%d%lld",&l,&r,&x);
            change(op,1,1,n,l,r,x);
        }
        if(op==3)
        {
            int l,r;
            scanf("%d%d",&l,&r);
            printf("%lld\n",query(1,1,n,l,r));
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/