#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,a[80010],st[80010],top;
LL ans=0;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        while(top && st[top]<=a[i]) top--;
        ans+=1LL*top;
        st[++top]=a[i];
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月27日 星期二
--------------------
*/