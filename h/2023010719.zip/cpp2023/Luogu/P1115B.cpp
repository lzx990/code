#include<bits/stdc++.h>
using namespace std;
int n,a[214514],ans=INT_MIN;
void ms(int l,int r)
{
    if(l==r)
    {
        ans=max(ans,a[l]);
        return;
    }
    int mid=(l+r)>>1;
    ms(l,mid);
    ms(mid+1,r);
    int ls=INT_MIN,rs=INT_MIN,s=0;
    for(int i=mid;i>=l;i--)
    {
        s+=a[i];
        ls=max(ls,s);
    }
    s=0;
    for(int i=mid+1;i<=r;i++)
    {
        s+=a[i];
        rs=max(rs,s);
    }
    ans=max(ls+rs,ans);
    return;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    ms(1,n);
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/