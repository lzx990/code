#include<bits/stdc++.h>
using namespace std;
int n,m,c[1010][1010];
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        int x0,y0,x2,y2;
        scanf("%d%d%d%d",&x0,&y0,&x2,&y2);
        c[x0][y0]++;
        c[x0][y2+1]--;
        c[x2+1][y0]--;
        c[x2+1][y2+1]++;
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            c[i][j]+=c[i-1][j]+c[i][j-1]-c[i-1][j-1];
            printf("%d ",c[i][j]);
        }
        puts("");
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/