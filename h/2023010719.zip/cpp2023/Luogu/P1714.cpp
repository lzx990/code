#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,m,l,r;
LL q[500010],s[500010],ans;
int main()
{  
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%lld",&x);
        s[i]=s[i-1]+x;
    }
    for(int i=1;i<=n;i++)
    {
        while(l<=r && q[l]+m<i) l++;
        ans=max(ans,s[i]-s[q[l]]);
        while(l<=r && s[q[r]]>=s[i]) r--;
        q[++r]=i;   
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/