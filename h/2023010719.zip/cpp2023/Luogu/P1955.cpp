#include<bits/stdc++.h>
using namespace std;
int T;
int n,m,li[2000010],fa[2000010];
struct node
{
    int x,y,z;
}a[1000010];
int find(int x)
{
    if(x==fa[x]) return x;
    return fa[x]=find(fa[x]);
}
void work()
{
    m=0;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].z);
        li[++m]=a[i].x;
        li[++m]=a[i].y;
    }
    sort(li+1,li+1+m);
    m=unique(li+1,li+1+m)-li-1;
    for(int i=1;i<=m;i++)
    {
        fa[i]=i;
    }
    for(int i=1;i<=n;i++)
    {
        a[i].x=lower_bound(li+1,li+1+m,a[i].x)-li;
        a[i].y=lower_bound(li+1,li+1+m,a[i].y)-li;
    }
    for(int i=1;i<=n;i++)
    {
        if(a[i].z)
        {
            fa[find(a[i].x)]=find(a[i].y);
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(!a[i].z)
        {
            if(find(a[i].x)==find(a[i].y))
            {
                puts("NO");
                return;
            }
        }
    }
    puts("YES");
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/