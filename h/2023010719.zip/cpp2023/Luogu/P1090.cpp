#include<bits/stdc++.h>
using namespace std;
int n,ans;
priority_queue <int> q;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%d",&x);
        q.push(-x);
    }
    while(q.size()>1)
    {
        int x=-q.top();
        q.pop();
        int y=-q.top();
        q.pop();
        ans+=x+y;
        q.push(-x-y);
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/