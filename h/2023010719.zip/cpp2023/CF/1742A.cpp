#include<bits/stdc++.h>
using namespace std;
int T;
int a[10];
void work()
{
    scanf("%d%d%d",&a[1],&a[2],&a[3]);
    if(a[1]+a[2]==a[3] || a[1]+a[3]==a[2] || a[2]+a[3]==a[1])
    {
        puts("YES");
    }
    else puts("NO");
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/