#include<bits/stdc++.h>
using namespace std;
int T;
int n;
void work()
{
    scanf("%d",&n);
    if(n%2==0)
    {
        for(int i=n;i;i--) printf("%d ",i);
    }
    else if(n==3)
    {
        printf("-1");
    }
    else if(n==5)
    {
        printf("3 4 5 1 2");
    }
    else
    {
        for(int i=n;i;i--)
        {
            if(i==n/2+1)
            {
                printf("%d ",n/2);
            }
            else if(i==n/2)
            {
                printf("%d ",n/2+1);
            }
            else printf("%d ",i);
        }
    }
    puts("");
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月31日 星期六
--------------------
*/