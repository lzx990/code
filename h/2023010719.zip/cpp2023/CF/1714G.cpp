#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAXN=2e5+10;
int T;
int n,zjh[2][MAXN*2],to[MAXN*2],nxt[MAXN*2],hed[MAXN*2],m,baba[MAXN][20],d[MAXN];
int s0[MAXN],s1[MAXN];
void add(int x,int y,int z1,int z2)
{
    zjh[0][++m]=z1;
    zjh[1][m]=z2;
    to[m]=y;
    nxt[m]=hed[x];
    hed[x]=m;
}
void dfs(int fa,int u)
{
    d[u]=d[fa]+1;
    baba[u][0]=fa;
    for(int i=1;i<=18;i++)
    {
        baba[u][i]=baba[baba[u][i-1]][i-1];
    }
    for(int i=hed[u];i;i=nxt[i])
    {
        int v=to[i];
        if(v==fa) continue;

        s0[v]=zjh[0][i]+s0[u];
        s1[v]=zjh[1][i]+s1[u];

        dfs(u,v);
    }
    return;
}
void work()
{
    m=0;
    scanf("%lld",&n);
    for(int i=0;i<=n+10;i++)
    {
        s1[i]=s0[i]=0;
        for(int j=0;j<=19;j++) baba[i][j]=0;
        d[i]=0;
    }
    baba[1][0]=1;
    for(int i=0;i<=n*2+10;i++)
    {
        zjh[1][i]=zjh[0][i]=0;
        to[i]=0;
        nxt[i]=0;
        hed[i]=0;
    }
    
    for(int i=2;i<=n;i++)
    {
        int fa,a,b;
        scanf("%lld%lld%lld",&fa,&a,&b);
        add(fa,i,a,b);
        add(i,fa,a,b);
    }
    dfs(0,1);
    for(int i=2;i<=n;i++)
    {
        int x=i,cnt=s0[i];
        for(int j=19;j>=0;j--)
        {
            if(s1[baba[x][j]]>=cnt)
            {
                x=baba[x][j];
            }
        }
        if(s1[x]>cnt) x=baba[x][0];
        printf("%lld ",d[x]-1);
    }
    puts("");
}
signed main()
{
    scanf("%lld",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/