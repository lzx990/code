#include<bits/stdc++.h>
using namespace std;
int T;
int n,a[2010];
void work()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    int s=0,ans=1919810;
    for(int i=1;i<=n;i++)
    {
        s+=a[i];
        int cnt=0,cc=0,ct=0;
        bool f=1;
        for(int j=1;j<=n;j++)
        {
            cnt+=a[j];
            cc++;
            if(cnt==s)
            {
                cnt=0;
                ct=max(ct,cc);
                cc=0;
            }
            else if(cnt>s)
            {
                f=0;
                break;
            }
        }
        if(cnt!=0)
        {
            f=0;
        }
        if(f)
        {
            ans=min(ct,ans);
        }
    }
    printf("%d\n",ans);
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月31日 星期六
--------------------
*/