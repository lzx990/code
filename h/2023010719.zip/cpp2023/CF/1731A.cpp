#include<bits/stdc++.h>
#define LL long long
using namespace std;
int T;
int n;
LL a,s=1;
void work()
{
    s=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a);
        s*=a;
    }
    printf("%lld\n",(s+n-1)*2022);
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月27日 星期二
--------------------
*/