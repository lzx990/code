#include<bits/stdc++.h>
using namespace std;
int T;

void work()
{
    int n,l=10;
    scanf("%d",&n);
    string x="";
    while(n)
    {
        int cnt=min(n,l-1);
        l=cnt;
        x+=char(cnt+48);
        n-=cnt;
    }
    reverse(x.begin(),x.end());
    cout<<x<<"\n";
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/