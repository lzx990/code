#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n,a[110];
int fib[100]={1,2};
int su[100],cntt;
int s[110];
bool ss(int x)
{
    if(x<2) return 0;
    for(int i=2;i*i<=x;i++)
    {
        if(x%i==0) return 0;
    }
    return 1;
}
void ycl()
{
    for(int i=2;i<=91;i++)
    {
        fib[i]=fib[i-1]+fib[i-2];
    }
    for(int i=2;i<=100;i++)
    {
        if(ss(i)) su[++cntt]=i;
    }
}
void work()
{
    scanf("%lld",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if(a[i]==a[j])
            {
                puts("NO");
                return;
            }
        }
    }
    for(int k=1;k<=cntt;k++)
    {
        //cerr<<"114514:"<<su[k]<<"\n";
        memset(s,0,sizeof s);
        for(int i=1;i<=n;i++)
        {
           s[a[i]%su[k]]++;
        }  
        bool f=0;
        for(int i=0;i<su[k];i++)
        {
            if(s[i]<2)
            {
                f=1;
            }
        } 
        if(!f)
        {
            puts("NO");
            return;
        }
    }
    puts("YES");
}
signed main()
{
    scanf("%lld",&T);
    ycl();
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月30日 星期五
--------------------
*/