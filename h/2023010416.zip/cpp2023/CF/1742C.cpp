#include<bits/stdc++.h>
using namespace std;
int T,n=8;
char s[10][10];
void work()
{
    for(int i=1;i<=8;i++)
    {
        scanf("%s",s[i]+1);
    }
    for(int i=1;i<=n;i++)
    {
        bool f=1;
        for(int j=1;j<=n;j++)
        {
            if(s[i][j]!='R')
            {
                f=0;
                break;
            }
        }
        if(f)
        {
            puts("R");
            return;
        }
    }
    for(int i=1;i<=n;i++)
    {
        bool f=1;
        for(int j=1;j<=n;j++)
        {
            if(s[j][i]!='B')
            {
                f=0;
                break;
            }
        }
        if(f)
        {
            puts("B");
            return;
        }
    }
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/