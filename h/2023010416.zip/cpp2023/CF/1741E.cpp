#include<bits/stdc++.h>
using namespace std;
int T;
int n,a[214514];
int f[214514];
void work()
{
    memset(f,0,sizeof f);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    f[0]=1;
    for(int i=0;i<=n;i++)
    {
        if(i-a[i]>0 && f[i-a[i]-1])
        {
            f[i]=1;
        }
        if(1+i+a[i+1]<=n && f[i])
        {
            f[1+i+a[i+1]]=1;
        }
    }
    if(f[n])
    {
        puts("YES");
    }
    else
    {
        puts("NO");
    }
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月31日 星期六
--------------------
*/