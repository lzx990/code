#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n,a[110],m,b[110];
priority_queue <int> q;
bool cmp(int x,int y)
{
    return x>y;
}
void work()
{
    int ans=0;
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
        q.push(-a[i]);
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%lld",&b[i]);
        q.pop();
        q.push(-b[i]);
    }
    while(!q.empty())
    {
        ans+=q.top();
        q.pop();
    }
    printf("%lld\n",-ans);
}
signed main()
{
    scanf("%lld",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月30日 星期五
--------------------
*/