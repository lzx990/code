#include<bits/stdc++.h>
#define LL long long
using namespace std;
int T;
int q;
string s;
void work()
{
    LL a1=0,a2=0,l1=0,l2=0;
    scanf("%d",&q);
    while(q--)
    {
        LL d,k;
        scanf("%lld %lld",&d,&k);
        cin>>s;
        bool a=1;
        int S=s.size();
        for(int i=0;i<S;i++)
        {
            if(s[i]!='a')
            {
                 a=0;
                 break;
            }
        }
        if(!a && d==1) a1=1;
        if(!a && d==2) a2=1;
        if(a && d==1) l1+=k*S;
        if(a && d==2) l2+=k*S;
        if(a2==1) puts("YES");
        else if(a1==1)
        {
            puts("NO");
        }
        else
        {
            if(l1<l2) puts("YES");
            else puts("NO");
        }
    }
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/