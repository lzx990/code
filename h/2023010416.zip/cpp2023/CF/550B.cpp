#include<bits/stdc++.h>
using namespace std;
int n,l,r,x,a[20],ans;
int main()
{
    scanf("%d%d%d%d",&n,&l,&r,&x);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1;i<=(1<<n)-1;i++)
    {
        int cnt=0,mx=-114514,mn=1919810;
        for(int j=1;j<=n;j++)
        {
            if((i>>(j-1))&1)
            {
                cnt+=a[j];
                mx=max(a[j],mx);
                mn=min(a[j],mn);
            }
        }
        if(l<=cnt && cnt<=r && mx-mn>=x)
        {
            ans++;
        }
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月25日 星期天
--------------------
*/