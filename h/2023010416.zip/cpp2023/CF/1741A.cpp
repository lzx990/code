#include<bits/stdc++.h>
using namespace std;
int T;
string s1,s2;
void work()
{
    cin>>s1>>s2;
    int a1,a2;
    if(s1=="M")
    {
        a1=0;
    }
    else if(s1[s1.size()-1]=='S')
    {
        a1=-(s1.size());
    }
    else
    {
        a1=s1.size();
    }

    if(s2=="M")
    {
        a2=0;
    }
    else if(s2[s2.size()-1]=='S')
    {
        a2=-(s2.size());
    }
    else
    {
        a2=s2.size();
    }
    if(a1<a2) puts("<");
    else if(a1==a2) puts("=");
    else puts(">");
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月31日 星期六
--------------------
*/