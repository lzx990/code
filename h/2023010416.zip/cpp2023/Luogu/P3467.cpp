#include<bits/stdc++.h>
using namespace std;
int n,a[250010],st[250010],top,ans;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d",&a[i],&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        while(top && st[top]>=a[i])
        {
            ans-=(st[top]==a[i])?1:0;
            top--;
        }
        st[++top]=a[i];
    }
    printf("%d\n",n+ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/