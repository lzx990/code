#include<bits/stdc++.h>
using namespace std;
int n,k,r=2,l[50010],a[50010],ans,ml;
int main()
{
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    sort(a+1,a+1+n);
    a[n+1]=2e9;
    for(int i=1;i<=n;i++)
    {
        while(r<=n && a[r]<=a[i]+k) r++;
        l[r]=max(l[r],r-i);
        ml=max(ml,l[i]);
        ans=max(ans,r-i+ml);
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/