#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL a,b,p;
LL kasumi(LL a,LL b,LL p)
{
    LL cnt=a,ans=1%p;
    while(b)
    {
        if(b&1)
        {
            ans=ans*cnt%p;
        }
        cnt=cnt*cnt%p;
        b>>=1;
    }
    return ans;
}
int main()
{
    scanf("%lld%lld%lld",&a,&b,&p);
    printf("%lld^%lld mod %lld=%lld\n",a,b,p,kasumi(a,b,p));
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/