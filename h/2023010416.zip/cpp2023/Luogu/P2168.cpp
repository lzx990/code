#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,k;
LL ans;
struct node
{
    LL w,h;
};
bool operator<(node s1,node s2)
{
    if(s1.w==s2.w) return s1.h>s2.h;
    return s1.w>s2.w;
}
priority_queue <node> q;
int main()
{
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)
    {
        LL x;
        scanf("%lld",&x);
        q.push({x,1});
    }
    if((n-1)%(k-1)!=0)
    {
       for(int i=1;i<=k-1-(n-1)%(k-1);i++)
       {
            q.push({0,1});
       } 
    }
    while(q.size()>1)
    {
        LL s=0,maxh=0;
        for(int i=1;i<=k;i++)
        {
            node cnt=q.top();
            q.pop();
            s+=cnt.w;
            maxh=max(maxh,cnt.h);
        }
        ans+=s;
        q.push({s,maxh+1});
    }
    printf("%lld\n%lld\n",ans,q.top().h-1);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/