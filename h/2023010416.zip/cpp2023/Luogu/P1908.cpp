#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL ans;
int b[514514],a[514514],n;
void ms(int a[],int l,int r)
{
    if(l==r) return;
    int mid=(l+r)>>1;
    ms(a,l,mid);
    ms(a,mid+1,r);
    for(int i=l,j=mid+1,k=l;k<=r;k++)
    {
        if(i==mid+1)
        {
            b[k]=a[j++];
        }
        else if(j==r+1)
        {
            b[k]=a[i++];
            ans+=(j-1)-(mid+1)+1LL;
        }
        else if(a[i]<=a[j])
        {
            b[k]=a[i++];
            ans+=(j-1)-(mid+1)+1LL;
        }
        else
        {
            b[k]=a[j++];
        }
    }
    for(int i=l;i<=r;i++)
    {
        a[i]=b[i];
    }
    return;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    ms(a,1,n);
    // for(int i=1;i<=n;i++)
    // {
    //     printf("%d ",a[i]);
    // }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/