#include<bits/stdc++.h>
using namespace std;
int n,m,s,b[1919810],a[1919810],ansl,ansr,ans=1919810;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    int l=1,r=0;
    while(l<=r+1 && r<=n)
    {
        if(s<m)
        {
            r++;
            if(!b[a[r]]) s++;
            b[a[r]]++;
        }
        else
        {
            if(r-l+1<ans)
            {  
                ans=r-l+1;
                ansl=l;
                ansr=r;
            }
            b[a[l]]--;
            if(!b[a[l]]) s--;
            l++;
        }
    }
    printf("%d %d\n",ansl,ansr);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月26日 星期一
--------------------
*/