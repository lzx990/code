#include<bits/stdc++.h>
using namespace std;
int n,k,q[2019810],a[2019810],l,r;
int main()
{
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        while(l<=r && q[l]+k<=i) l++;
        while(l<=r && a[q[r]]<a[i]) r--;
        q[++r]=i;
        if(i>=k)
        {
            printf("%d\n",a[q[l]]);
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月28日 星期三
--------------------
*/