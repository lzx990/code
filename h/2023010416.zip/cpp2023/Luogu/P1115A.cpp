#include<bits/stdc++.h>
using namespace std;
int n,a,f,ans=-114514;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a);
        f=max(f+a,a);
        ans=max(ans,f);
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月26日 星期一
--------------------
*/