#include<bits/stdc++.h>
using namespace std;
int n,q,a[8010];
struct node
{
    int v,id;
}b[8010];
int pos[8010];
bool cmp(node s1,node s2)
{
    if(s1.v==s2.v)
    {
        if(s1.id>s2.id)
        {
            swap(pos[s1.id],pos[s2.id]);
            return 0;
        }
        return 1;
    }
    if(s1.v>s2.v)
    {
        swap(pos[s1.id],pos[s2.id]);
        return 0;
    }
    return 1;
}
int main()
{
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        b[i].v=a[i];
        b[i].id=i;
        pos[i]=i;
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=i;j>=2;j--)
        {
            if(!cmp(b[j-1],b[j]))
            {
                swap(b[j-1],b[j]);
            }
        }
    }
    // for(int i=1;i<=n;i++)
    // {
    //     cerr<<b[i].v<<" ";
    // }
    // cerr<<"\n\n\n\n\n";
    while(q--)
    {
        int op,x,v;
        scanf("%d",&op);
        if(op==1)
        {
            scanf("%d%d",&x,&v);
            if(v>a[x])
            {
                a[x]=v;
                b[pos[x]].v=v;
                for(int i=pos[x]+1;i<=n;i++)
                {
                    if(!cmp(b[i-1],b[i]))
                    {
                        swap(b[i-1],b[i]);
                        //pos[b[i-1].id]=i-1;
                        //pos[b[i].id]=i;
                    }
                }
            }
            else if(v<a[x])
            {
                a[x]=v;
                b[pos[x]].v=v;
                for(int i=pos[x]-1;i;i--)
                {
                    if(!cmp(b[i],b[i+1]))
                    {
                        swap(b[i+1],b[i]);
                        //pos[b[i+1].id]=i+1;
                        //pos[b[i].id]=i;
                    }
                }
            }
        }
        else
        {
            scanf("%d",&x);
            printf("%d\n",pos[x]);
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/