#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,m,l[214514],r[214514];
LL s,w[214514],v[214514];
LL L,R,sg[214514],sv[214514],ans=1145141919810;
int main()
{
    scanf("%d%d%lld",&n,&m,&s);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld%lld",&w[i],&v[i]);
        R=max(w[i],R);
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&l[i],&r[i]);
    }
    R++;
    while(L<R)
    {
        LL mid=(L+R)>>1;
        memset(sg,0,sizeof(sg));
        memset(sv,0,sizeof(sv));
        LL cnt=0;
        for(int i=1;i<=n;i++)
        {
            if(w[i]>=mid)
            {
                sg[i]=sg[i-1]+1;
                sv[i]=sv[i-1]+v[i];
            }
            else
            {
                sg[i]=sg[i-1];
                sv[i]=sv[i-1];
            }
        }
        for(int i=1;i<=m;i++)
        {
            cnt+=(sg[r[i]]-sg[l[i]-1])*(sv[r[i]]-sv[l[i]-1]);
        }
        if(cnt==s)
        {
            puts("0");
            return 0;
        }
        ans=min(ans,abs(cnt-s));
        if(cnt<s) R=mid;
        else L=mid+1;
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/