#include<bits/stdc++.h>
using namespace std;
int n,k,a[1000010],l,r,q[1000010];
bool vs(int op,int x,int y)
{
    if(op)
    {
        return (x<=y);
    }
    return (x>=y);
}
int main()
{
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }  
    for(int zjh=0;zjh<2;zjh++)
    {
        l=0;r=0;
        for(int i=1;i<=n;i++)
        {
            while(l<=r && q[l]+k<=i) l++;
            while(l<=r && vs(zjh,a[q[r]],a[i])) r--;
            q[++r]=i;
            if(i>=k)
            {
                printf("%d ",a[q[l]]);
            }
        }
        puts("");
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/