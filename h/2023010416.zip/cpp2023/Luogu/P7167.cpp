#include<bits/stdc++.h>
using namespace std;
int to[114514][20],s[114514][20],lg2[114514],stD[114514][20],n,q,d[114514],c[114514],r,v;
void init()
{
    for(int i=2;i<=n;i++)
    {
        lg2[i]=lg2[(i>>1)]+1;
    }
    return;
}
int query(int l,int r)
{
    int k=lg2[r-l+1];
    return max(stD[l][k],stD[r-(1<<k)+1][k]);
}
int main()
{
    scanf("%d%d",&n,&q);
    init();
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d",&d[i],&c[i]);
        stD[i][0]=d[i];
    }
    for(int i=1;(1<<i)<=n;i++)
    {
        for(int j=1;j<=n-(1<<i)+1;j++)
        {
            stD[j][i]=max(stD[j][i-1],stD[j+(1<<(i-1))][i-1]);
        }
    }
    c[n+1]=1e9+7;
    for(int i=1;i<n;i++)
    {
        int l=i+1,r=n+1;
        while(l<r)
        {
            int mid=(l+r)>>1;
            if(query(i+1,mid)<=d[i])
            {
                l=mid+1;
            }
            else
            {
                r=mid;
            }
        }
        to[i][0]=l;
        s[i][0]=c[l];
    }
    to[n][0]=n+1;
    s[n][0]=c[n+1];
    for(int i=1;i<=17;i++)
    {
        for(int j=1;j<=n;j++)
        {
            to[j][i]=to[to[j][i-1]][i-1];
            s[j][i]=s[j][i-1]+s[to[j][i-1]][i-1];
        }
    }
    while(q--)
    {
        scanf("%d%d",&r,&v);
        if(v>c[r])
        {
            v-=c[r];
            for(int i=17;i>=0;i--)
            {
                //cerr<<v<<" "<<s[r][i]<<"\n";
                if(v>s[r][i])
                {
                    //cerr<<i<<"\n";
                    v-=s[r][i];
                    r=to[r][i];
                }           
            }
            r=to[r][0];
        }
        if(r==n+1) puts("0");
        else printf("%d\n",r);
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/