#include<bits/stdc++.h>
using namespace std;
int n,w,b[610],s;
int main()
{
    scanf("%d%d",&n,&w);
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%d",&x);
        b[x]++;
        s=0;
        for(int j=600;j>=0;j--)
        {
            s+=b[j];
            if(s>=max(1,w*i/100))
            {
                printf("%d ",j);
                break;
            }
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月26日 星期一
--------------------
*/