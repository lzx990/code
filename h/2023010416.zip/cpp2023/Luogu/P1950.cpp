#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,m,h[1010],l[1010],r[1010],st[1010],top;
char mp[1010][1010];
LL ans;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%s",mp[i]+1);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            h[j]=(mp[i][j]=='.')?(h[j]+1):(0);
        }
        for(int j=1;j<=m;j++)
        {
            while(top && h[j]<h[st[top]])
            {
                r[st[top]]=j;
                top--;
            }
            st[++top]=j;
        }
        while(top)
        {
            r[st[top]]=m+1;
            top--;
        }
        for(int j=m;j;j--)
        {
            while(top && h[j]<=h[st[top]])
            {
                l[st[top]]=j;
                top--;
            }
            st[++top]=j;
        }
        while(top)
        {
            l[st[top]]=0;
            top--;
        }
        for(int j=1;j<=m;j++)
        {
            //cout<<r[j]<<" "<<l[j]<<" "<<h[j]<<"\n";
            ans+=1LL*(j-l[j])*(r[j]-j)*h[j];
        }
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月27日 星期二
--------------------
*/