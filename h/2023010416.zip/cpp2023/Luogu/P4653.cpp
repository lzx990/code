#include<bits/stdc++.h>
using namespace std;
int n;
double ans,a[114514],b[114514];
bool vis1[114514],vis2[114514];
bool cmp(double x,double y)
{
    return x>y;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%lf%lf",&a[i],&b[i]);
    }
    double s1=0,s2=0;
    int p1=1,p2=1;
    sort(a+1,a+1+n,cmp);
    sort(b+1,b+1+n,cmp);
    while(p1<=n && p2<=n)
    {
        s1+=a[p1]*(1-vis1[p1]);
        s2+=b[p2]*(1-vis2[p2]);
        ans=max(ans,min(s1,s2)-p1-p2);
        vis1[p1]=1;
        vis2[p2]=1;
        if(s1>s2) p2++;
        else p1++; 
    }
    printf("%.4lf\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/