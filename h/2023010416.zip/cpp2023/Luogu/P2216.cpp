#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1010][1010],q[1010],l,r,b[2][1010][1010],c[2][1010][1010],ans=INT_MAX;
int main()
{
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=1;i<=n;i++)
    {
        l=r=0;
        for(int j=1;j<=m;j++)
        {
            while(l<=r && q[l]+k<=j) l++;
            while(l<=r && a[i][q[r]]<=a[i][j]) r--;
            q[++r]=j;
            if(j>=k)
            {
                b[0][i][j-k+1]=a[i][q[l]];
            }
        }

        l=r=0;
        for(int j=1;j<=m;j++)
        {
            while(l<=r && q[l]+k<=j) l++;
            while(l<=r && a[i][q[r]]>=a[i][j]) r--;
            q[++r]=j;
            if(j>=k)
            {
                b[1][i][j-k+1]=a[i][q[l]];
            }
        }
    }
    for(int i=1;i<=m-k+1;i++)
    {
        l=r=0;
        for(int j=1;j<=n;j++)
        {
            while(l<=r && q[l]+k<=j) l++;
            while(l<=r && b[0][q[r]][i]<=b[0][j][i]) r--;
            q[++r]=j;
            if(j>=k)
            {
                c[0][j-k+1][i]=b[0][q[l]][i];
            }
        }

        l=r=0;
        for(int j=1;j<=n;j++)
        {
            while(l<=r && q[l]+k<=j) l++;
            while(l<=r && b[1][q[r]][i]>=b[1][j][i]) r--;
            q[++r]=j;
            if(j>=k)
            {
                c[1][j-k+1][i]=b[1][q[l]][i];
            }
        }
    }
    for(int i=1;i<=n-k+1;i++)
    {
        for(int j=1;j<=m-k+1;j++)
        {
            ans=min(c[0][i][j]-c[1][i][j],ans);
        }
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月28日 星期三
--------------------
*/