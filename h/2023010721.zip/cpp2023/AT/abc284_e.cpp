#include<bits/stdc++.h>
using namespace std;
int n,ans,m;
vector <int> V[200010];
bool vis[200010];
void mx()
{
    if(ans>=1e6)
    {
        cout<<int(1e6)<<"\n";
        exit(0);
    }
}
void dfs(int u,int fa)
{
    vis[u]=1;
    ans++;
    mx();
    for(auto v:V[u])
    {
        if(v==fa) continue;
        if(!vis[v]) dfs(v,u);
    }
    vis[u]=0;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        V[x].push_back(y);
        V[y].push_back(x);
    }
    dfs(1,-114514);
    cout<<ans<<"\n";
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/