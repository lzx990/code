#include<bits/stdc++.h>
using namespace std;
int n,m,fa[110];
int find(int x)
{
    if(x==fa[x]) return x;
    return fa[x]=find(fa[x]);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++) fa[i]=i;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        fa[find(x)]=find(y);
    }
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        if(i==fa[i]) ans++;
    }
    cout<<ans<<"\n";
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/