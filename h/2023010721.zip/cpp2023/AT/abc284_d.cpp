#include<bits/stdc++.h>
#define LL unsigned long long
using namespace std;
int T;
LL n;
void work()
{
    cin>>n;
    for(LL i=2;i<=min((LL)cbrt(n)*10,n);i++)
    {
        if(n%(i*i)==0)
        {
            cout<<i<<" "<<n/i/i<<"\n";
            return;
        }
        if(n%(i)==0 && (LL)(sqrt(n/i))*(LL)(sqrt(n/i))==n/i)
        {
            cout<<(LL)sqrt(n/i)<<" "<<i<<"\n";
            return;
        }
    }
}
int main()
{
    cin>>T;
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/