#include<bits/stdc++.h>
#define LL long long
using namespace std;
const LL MOD=1e9+7;
const int MAXN=1000010;
LL ans,q,c,q1[MAXN],q2[MAXN];
int n,m,k;
char op[2];
int main()
{
    for(int i=1;i<MAXN;i++)
    {
        q1[i]=q2[i]=1;
    }
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=k;i++)
    {
        int x;LL y;
        scanf("%s%d%lld",op,&x,&y);
        if(op[0]=='R') q1[x]=q1[x]*y%MOD;
        if(op[0]=='S') q2[x]=q2[x]*y%MOD;
    }
    for(int i=1;i<=n;i++)
    {
        q=(q+(1LL*(i-1)*m+1)%MOD*q1[i])%MOD;
        c=(c+q1[i])%MOD;
    }
    for(int i=1;i<=m;i++)
    {
        ans=(ans+q*q2[i]%MOD)%MOD;
        q=(q+c)%MOD;
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/