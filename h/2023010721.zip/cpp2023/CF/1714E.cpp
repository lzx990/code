#include<bits/stdc++.h>
using namespace std;
int T;
int n,a[200010],gl[]={0,2,4,8,6};
int getto(int x)
{
    while(x%10!=2)
    {
        x+=x%10;
    }
    return x;
}
void work()
{
    scanf("%d",&n);
    bool f=0;
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        if(a[i]%10==0 || a[i]%10==5) f=1;
    }
    if(f)
    {
        int a5=-114514,a10=-114514;
        for(int i=1;i<=n;i++)
        {
            if(a[i]%10!=0 && a[i]%10!=5)
            {
                puts("No");
                return;
            }
            if(a[i]%10==5)
            {
                if(a5!=a[i] && a5!=-114514)
                {
                    puts("No");
                    return;
                }
                a5=a[i];
            }
            if(a[i]%10==0)
            {
                if(a10!=a[i] && a10!=-114514)
                {
                    puts("No");
                    return;
                }
                a10=a[i];
            }
        }
        if(a5+5==a10 || a5==-114514 || a10==-114514)
        {
            puts("Yes");
        }
        else puts("No");
        return;
    }
    for(int i=1;i<=n;i++)
    {
        a[i]=getto(a[i]);
    }
    sort(a+1,a+1+n);
    for(int i=1;i<n;i++)
    {
        if((a[i+1]-a[i])%20!=0)
        {
            puts("No");
            return;
        }
    }
    puts("Yes");
    return;
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/