#include<bits/stdc++.h>
using namespace std;
__int128 MOD=1e9+7;
inline __int128 read()
{
    __int128 x=0,f=1;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}
inline void write(__int128 x)
{
    if (x<0)
    {
        putchar('-');
        x=-x;
    }
    if (x>9) write(x/10);
    putchar(x%10+'0');
}
__int128 n,T;
void work()
{
    n=read();
    write((n*(n+1)*(2*n+1)/3-n*(n+1)/2)%MOD*2022%MOD);
    puts("");
}
signed main()
{
    //scanf("%d",&T);
    //int id=0;
    T=read();
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月27日 星期二
--------------------
*/