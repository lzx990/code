#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n,a[214514],st[214514],top;
bool vis[214514];
// bool cmp(int s1,int s2)
// {
//     return s1>s2;
// }
void work()
{
    int ans=0;
    top=0;
    scanf("%lld",&n);
    memset(vis,0,sizeof vis);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    //sort(a+1,a+1+n,cmp);
    for(int i=1;i<=min(40LL,n);i++)
    {
        int cnt=0,x=0;
        for(int j=1;j<=n;j++)
        {
            if((ans|a[j])>cnt)
            {
                cnt=(ans|a[j]);
                x=j;
            }
        }
        if(ans==cnt) break;
        ans=cnt;
        st[++top]=a[x];
        vis[x]=1;
    }
    for(int i=1;i<=n;i++)
    {
        if(!vis[i])
        {
            st[++top]=a[i];
        }
    }
    for(int i=1;i<=n;i++)
    {
        printf("%lld ",st[i]);
    }
    puts("");
}
signed main()
{
    scanf("%lld",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/