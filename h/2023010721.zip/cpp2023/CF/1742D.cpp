#include<bits/stdc++.h>
using namespace std;
int T;
int n,b[1010],b1[1010],b2[1010];
void work()
{
    scanf("%d",&n);
    memset(b,0,sizeof b);
    memset(b1,0,sizeof(b1));
    memset(b2,0,sizeof(b2));
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%d",&x);
        b[x]++;
        b1[x]=i;
    }
    int ans=-1;
    for(int i=1;i<=1000;i++)
    {
        if(!b[i]) continue;
        // if(i==1 && b[1]>=2)
        // {
        //     ans=max(ans,b1[1]+b2[1]);
        // }
        for(int j=i;j<=1000;j++)
        {
            if(!b[j]) continue;
            if(__gcd(i,j)!=1)
            {
                continue;
            }
            if(i!=j)
            ans=max(ans,b1[i]+b1[j]);
            else
            ans=max(ans,b1[i]*2);
        }
    }
    printf("%d\n",ans);
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月24日 星期六
--------------------
*/