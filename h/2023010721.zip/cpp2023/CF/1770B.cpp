#include<bits/stdc++.h>
using namespace std;
int T;
int n,k;
void work()
{
    scanf("%d%d",&n,&k);
    int c1=0,c2=n+1,c=0;
    if(k==1)
    {
        for(int i=1;i<=n;i++)
        printf("%d ",i);
        puts("");
        return;
    }
    for(int i=1;;i++)
    {
        for(int j=1;j<k;j++)
        {
            if(i%2==1)
            {
                c++;
                if(c>n)
                {
                    puts("");
                    return;
                }
                c2--;
                printf("%d ",c2);
            }
            else
            {
                c++;
                if(c>n)
                {
                    puts("");
                    return;
                }
                c1++;
                printf("%d ",c1);
            }
        }
    }
    puts("");
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月30日 星期五
--------------------
*/