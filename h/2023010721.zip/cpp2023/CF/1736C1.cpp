#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n;
void work()
{
    scanf("%lld",&n);
    int ans=0;
    int l=1;
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%lld",&x);
        l=max(l,i-x+1);
        ans+=i-l+1;
    }
    printf("%lld\n",ans);
}
signed main()
{
    scanf("%lld",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/