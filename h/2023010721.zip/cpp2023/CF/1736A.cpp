#include<bits/stdc++.h>
using namespace std;
int T;
int n,a[110],b[110],bin[2];
void work()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&b[i]);
    }
    int s1=0,s2=0;
    for(int i=1;i<=n;i++)
    {
        s1+=bool(a[i]!=b[i]);
    }
    memset(bin,0,sizeof bin);
    for(int i=1;i<=n;i++)
    {
        bin[0]+=a[i];
        bin[1]+=b[i];
    }
    printf("%d\n",min(s1,abs(bin[0]-bin[1])+1));
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月07日 星期六
--------------------
*/