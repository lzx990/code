#include<bits/stdc++.h>
using namespace std;
int T;
int m,ans,a[262150];
void merge(int l,int r)
{
    int md=l+(r-l+1)/2,mid=(r-l+1)/2;
    if(l==r) return;
    merge(l,md-1);
    merge(md,r);
    if(a[l]>=a[md])
    {
        ans++;
        for(int i=l;i<md;i++)
        {
            swap(a[i],a[i+mid]);
        }
    }
    return;
}
void work()
{
    ans=0;
    scanf("%d",&m);
    for(int i=1;i<=m;i++)
    {
        scanf("%d",&a[i]);
    }
    merge(1,m);
    for(int i=1;i<=m;i++)
    {
        if(a[i]!=i)
        {
            puts("-1");
            return;
        }
    }
    printf("%d\n",ans);
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月31日 星期六
--------------------
*/