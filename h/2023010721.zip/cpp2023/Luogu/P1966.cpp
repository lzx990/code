#include<bits/stdc++.h>
#define LL long long
using namespace std;
const LL MOD=1e8-3;
LL ans;
int b[114514],a[114514],c[114514],d[114514],li[114514],m,n;
void ms(int a[],int l,int r)
{
    if(l==r) return;
    int mid=(l+r)>>1;
    ms(a,l,mid);
    ms(a,mid+1,r);
    for(int i=l,j=mid+1,k=l;k<=r;k++)
    {
        if(i==mid+1)
        {
            b[k]=a[j++];
        }
        else if(j==r+1)
        {
            b[k]=a[i++];
            ans+=(j-1)-(mid+1)+1LL;
            ans%=MOD;
        }
        else if(a[i]<=a[j])
        {
            b[k]=a[i++];
            ans+=(j-1)-(mid+1)+1LL;
            ans%=MOD;
        }
        else
        {
            b[k]=a[j++];
        }
    }
    for(int i=l;i<=r;i++)
    {
        a[i]=b[i];
    }
    return;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&c[i]);
        li[++m]=c[i];
    }
    sort(li+1,li+1+m);
    m=unique(li+1,li+1+m)-li-1;
    for(int i=1;i<=n;i++)
    {
        int x=lower_bound(li+1,li+1+m,c[i])-li;
        c[i]=x;
    }
    m=0;
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&d[i]);
        li[++m]=d[i];
    }
    sort(li+1,li+1+m);
    m=unique(li+1,li+1+m)-li-1;
    for(int i=1;i<=n;i++)
    {
        int x=lower_bound(li+1,li+1+m,d[i])-li;
        d[i]=x;
    }
    for(int i=1;i<=n;i++)
    {
        a[d[i]]=i;
    }
    for(int i=1;i<=n;i++)
    {
        c[i]=a[c[i]];
    }
    ms(c,1,n);
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月01日 星期天
--------------------
*/