#include<bits/stdc++.h>
using namespace std;
int n,q,lg2[50010],st[2][50010][20];
int M(int op,int a,int b)
{
    if(!op)
    {
        return (a<b)?a:b;
    }
    if(op)
    {
        return (a>b)?a:b;
    }
}
void init()
{
    for(int i=2;i<=n;i++)
    {
        lg2[i]=lg2[(i>>1)]+1;
    }
    for(int k=0;k<=1;k++)
    {
        for(int i=1;(1<<i)<=n;i++)
        {
            for(int j=1;j<=n+1-(1<<i);j++)
            {
                st[k][j][i]=M(k,st[k][j][i-1],st[k][j+(1<<(i-1))][i-1]);
            }
        }
    }
}
int query(int op,int l,int r)
{
    int k=lg2[r-l+1];
    return M(op,st[op][l][k],st[op][r-(1<<k)+1][k]);
}
int main()
{
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&st[1][i][0]);
        st[0][i][0]=st[1][i][0];
    }
    init();
    while(q--)
    {
        int l,r;
        scanf("%d%d",&l,&r);
        printf("%d\n",query(1,l,r)-query(0,l,r));
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/