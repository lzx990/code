#include<bits/stdc++.h>

#define lc (rt<<1)
#define rc ((rt<<1)|1)
#define md ((l+r)>>1)
#define LL long long

using namespace std;

int n,m;
LL a[100010],tag[400010];
struct node
{
    LL v;
}seg[400010];

bool inseg(int l,int r,int L,int R)
{
    return ((L<=l) && (r<=R));
}
bool outseg(int l,int r,int L,int R)
{
    return ((l>R) || (r<L));
}
void gettag(int rt,int len,LL x)
{
    tag[rt]+=x;
    seg[rt].v+=x*len;
}

void pushup(int rt)
{
    seg[rt].v=seg[lc].v+seg[rc].v;
    return;
}
void pushdown(int rt,int l,int r)
{
    gettag(lc,md-l+1,tag[rt]);
    gettag(rc,r-md,tag[rt]);
    tag[rt]=0;
    return;
}
void build(int rt,int l,int r)
{
    if(l==r)
    {
        seg[rt].v=a[l];
        return;
    }
    build(lc,l,md);
    build(rc,md+1,r);
    pushup(rt);
    return;
}
void change(int rt,int l,int r,int L,int R,LL k)
{
    if(inseg(l,r,L,R))
    {
        gettag(rt,r-l+1,k);
        return;
    }
    else if(!outseg(l,r,L,R))
    {
        pushdown(rt,l,r);
        change(lc,l,md,L,R,k);
        change(rc,md+1,r,L,R,k);
        pushup(rt);
        return;
    }
    return;
}
LL query(int rt,int l,int r,int L,int R)
{
    if(inseg(l,r,L,R))
    {
        return seg[rt].v;
    }
    else if(outseg(l,r,L,R))
    {
        return 0;
    }
    else
    {
        pushdown(rt,l,r);
        return query(lc,l,md,L,R)+query(rc,md+1,r,L,R);
    }
}

int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
    }
    build(1,1,n);
    while(m--)
    {
        int op;
        scanf("%d",&op);
        if(op==1)
        {
            int x,y;
            LL k;
            scanf("%d%d%lld",&x,&y,&k);
            change(1,1,n,x,y,k);
        }
        if(op==2)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            printf("%lld\n",query(1,1,n,x,y));
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/