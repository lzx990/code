#include<bits/stdc++.h>
using namespace std;
int n,m,q,u,v,t;
struct Q
{
    int q[8100010],l,r;
}a[3];
bool cmp(int x,int y)
{
    return x>y;
}
int getmax()
{
    int m0=-1e9,m1=-1e9,m2=-1e9;
    if(a[0].r>=a[0].l)
    {
        m0=a[0].q[a[0].l];
    }
    if(a[1].r>=a[1].l)
    {
        m1=a[1].q[a[1].l];
    }
    if(a[2].r>=a[2].l)
    {
        m2=a[2].q[a[2].l];
    }

    if(m0>=m1 && m0>=m2)
    {
        a[0].l++;
        return m0;
    }
    if(m1>=m0 && m1>=m2)
    {
        a[1].l++;
        return m1;
    }
    if(m2>=m0 && m2>=m1)
    {
        a[2].l++;
        return m2;
    }
}
int main()
{
    scanf("%d%d%d%d%d%d",&n,&m,&q,&u,&v,&t);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[0].q[i]);
    }
    sort(a[0].q+1,a[0].q+1+n,cmp);
    a[0].l=1,a[0].r=n;
    a[1].l=1,a[1].r=0;
    a[2].l=1,a[2].r=0;
    for(int i=1;i<=m;i++)
    {
        int l=getmax()+q*(i-1);
        if(i%t==0)
        {
            printf("%d ",l);
        }
        int x=1LL*l*u*1.0/v;
        int y=l-x;
        x-=q*i;
        y-=q*i;
        a[1].q[++a[1].r]=x;
        a[2].q[++a[2].r]=y;
    }
    puts("");
    for(int i=1;i<=n+m;i++)
    {
        int l=getmax()+m*q;
        if(i%t==0) printf("%d ",l);
    }
    puts("");
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/