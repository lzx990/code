#include<bits/stdc++.h>
using namespace std;
int n,L,R,a[200010],l,r,q[200010],ans=-1e9,f[200010];
int main()
{
    memset(f,-0x3f,sizeof f);
    scanf("%d%d%d",&n,&L,&R);
    for(int i=0;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    f[0]=0;
    for(int i=L;i<=n;i++)
    {
        while(l<=r && q[l]+R<i) l++;
        while(l<=r && f[q[r]]<=f[i-L]) r--;
        q[++r]=i-L;
        f[i]=f[q[l]]+a[i];
        if(i+R>n)
        {
            ans=max(f[i],ans);
        }
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/