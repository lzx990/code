#include<bits/stdc++.h>
#define LL long long
using namespace std;
const LL MOD=10007;
int n,m;
LL a[114514],c[114514],s1[114514][2],s2[114514][2],ans;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
    }
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&c[i]);
        s1[c[i]][i%2]++;
        s2[c[i]][i%2]=(s2[c[i]][i%2]+a[i])%MOD;
    }
    for(int i=1;i<=n;i++)
    {
        ans=(ans+1LL*i*((s2[c[i]][i%2]-a[i])+(a[i]*(s1[c[i]][i%2]-1)%MOD))%MOD)%MOD;
    }
    printf("%lld\n",(ans+MOD)%MOD);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月26日 星期一
--------------------
*/