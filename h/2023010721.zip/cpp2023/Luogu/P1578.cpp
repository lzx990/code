#include<bits/stdc++.h>
using namespace std;
int L,W,n,ans;
struct node
{
    int x,y;
}a[5010];
bool cmp1(node s1,node s2)
{
    if(s1.x==s2.x) return s1.y<s2.y;
    return s1.x<s2.x;
}
bool cmp2(node s1,node s2)
{
    if(s1.y==s2.y) return s1.x<s2.x;
    return s1.y<s2.y;
}
int main()
{
    scanf("%d%d%d",&L,&W,&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d",&a[i].x,&a[i].y);
    }
    a[++n].x=0;a[n].y=0;
    a[++n].x=0;a[n].y=W;
    a[++n].x=L;a[n].y=0;
    a[++n].x=L;a[n].y=W;
    sort(a+1,a+1+n,cmp1);
    for(int i=1;i<=n;i++)
    {
        int x0=a[i].x,x2,y0=0,y2=W;
        for(int j=i+1;j<=n;j++)
        {
            x2=a[j].x;
            ans=max(ans,(x2-x0)*(y2-y0));
            if(a[j].y>a[i].y)
            {
                y2=min(y2,a[j].y);
            }
            else
            {
                y0=max(y0,a[j].y);
            }
        }
    }
    for(int i=n;i;i--)
    {
        int x0=a[i].x,x2,y0=0,y2=W;
        for(int j=i-1;j;j--)
        {
            x2=a[j].x;
            ans=max(ans,(x2-x0)*(y2-y0));
            if(a[j].y>a[i].y)
            {
                y2=min(y2,a[j].y);
            }
            else
            {
                y0=max(y0,a[j].y);
            }
        }
    }
    sort(a+1,a+1+n,cmp2);
    for(int i=2;i<=n;i++)
    {
        ans=max(ans,L*(a[i].y-a[i-1].y));
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月02日 星期一
--------------------
*/