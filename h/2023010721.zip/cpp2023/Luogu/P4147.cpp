#include<bits/stdc++.h>
using namespace std;
int ans,n,m,l[1010][1010],r[1010][1010],h[1010][1010];
char mp[1010][1010];
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            cin>>mp[i][j];
            l[i][j]=r[i][j]=j;
            h[i][j]=1;
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(mp[i][j-1]=='F' && mp[i][j]=='F')
            {
                l[i][j]=l[i][j-1];
            }
        }
        for(int j=m;j;j--)
        {
            if(mp[i][j+1]=='F' && mp[i][j]=='F')
            {
                r[i][j]=r[i][j+1];
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(mp[i][j]!='F') continue;
            if(i!=1 && mp[i-1][j]=='F')
            {
                l[i][j]=max(l[i][j],l[i-1][j]);
                r[i][j]=min(r[i][j],r[i-1][j]);
                h[i][j]=h[i-1][j]+1;
            }
            ans=max(ans,h[i][j]*(r[i][j]-l[i][j]+1));

        }
    }
    printf("%d\n",3*ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月27日 星期二
--------------------
*/