#include<bits/stdc++.h>
#define LL long long
using namespace std;
int n,c,a[214514];
LL ans;
int main()
{
    scanf("%d%d",&n,&c);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    sort(a+1,a+1+n);
    int l=1,r=1;
    for(int i=1;i<=n;i++)
    {
        while(a[l]<a[i]-c && l<n) l++;
        while(a[r]<=a[i]-c && r<n) r++;
        if(a[i]-a[l]==c)
        {
            ans+=0LL+r-l;
        }
    }
    printf("%lld\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月25日 星期天
--------------------
*/