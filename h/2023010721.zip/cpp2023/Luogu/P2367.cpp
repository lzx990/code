#include<bits/stdc++.h>
using namespace std;
int n,p,a[5000010],c[5000010],ans=INT_MAX;
int main()
{
    scanf("%d%d",&n,&p);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=1;i<=p;i++)
    {
        int l,r,z;
        scanf("%d%d%d",&l,&r,&z);
        c[l]+=z;
        c[r+1]-=z;
    }
    for(int i=1;i<=n;i++)
    {
        c[i]+=c[i-1];
        ans=min(c[i]+a[i],ans);
    }
    printf("%d\n",ans);
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月30日 星期五
--------------------
*/