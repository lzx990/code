#include<bits/stdc++.h>
using namespace std;
int n,d[1000010],m;
void push(int x)
{
    d[++m]=x;
    int cnt=m;
    while(cnt>1 && d[cnt/2]>d[cnt])
    {
        swap(d[cnt/2],d[cnt]);
        cnt/=2;
    }
    return;
}
void pop()
{
    swap(d[1],d[m]);
    m--;
    int cnt=1;
    while(cnt*2<=m)
    {
        int tnc=cnt;
        cnt*=2;
        if(tnc*2+1<=m && d[cnt+1]<d[cnt]) cnt++;
        if(d[tnc]>d[cnt])
        {
            swap(d[tnc],d[cnt]);
        }
        else break;
    }
    return;
}
int top()
{
    return d[1];
}
int main()
{
    scanf("%d",&n);
    while(n--)
    {
        int op;
        scanf("%d",&op);
        if(op==1)
        {
            int x;
            scanf("%d",&x);
            push(x);
        }
        else if(op==2)
        {
            printf("%d\n",top());
        }
        else if(op==3)
        {
            pop();
        }
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2023年01月03日 星期二
--------------------
*/