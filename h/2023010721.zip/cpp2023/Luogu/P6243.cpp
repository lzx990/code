#include<bits/stdc++.h>
using namespace std;
int n;
struct node
{
	int a,b;
}c[25010];
bool cmp(node s1,node s2)
{
	
	return min(s1.a,s2.b)<min(s1.b,s2.a);
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&c[i].a,&c[i].b);
	}
	int s=0,ss=0;
	sort(c+1,c+1+n,cmp);
	for(int i=1;i<=n;i++)
	{
		ss+=c[i].a;
		s=max(s+c[i].b,ss+c[i].b);
	}
	printf("%d\n",s);
	return 0;
}
/*
Write By : lzx
RP++
--------------------
NOTES:
第二项时间花费+等待时间 
*/