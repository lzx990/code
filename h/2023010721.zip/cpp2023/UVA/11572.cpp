#include<bits/stdc++.h>
using namespace std;
int T;
int ans,n,a[1019810],m;
map <int,int> b;
map <int,bool> v;
void work()
{
    ans=0;
    scanf("%d",&n);
    v.clear();
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    b.clear();
    int l=1,r=0,s=0;
    while(l<=r+1 && r<=n)
    {
        if(!s)
        {
            ans=max(ans,r-l+1);
            r++;
            if(b[a[r]]==1) s++; 
            b[a[r]]++;
        }
        else
        {
            b[a[l]]--;
            if(b[a[l]]==1) s--;
            l++;
        }
    }
    printf("%d\n",ans);
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        work();
    }
    return 0;
}
/*
--------------------
作者 lzx
语言 C++
祝愿 RP++
时间 2022年12月29日 星期四
--------------------
*/